/*
@Author Eddy Henle and Chris Cash
@A00214919
@Assignment Snakes and Ladders Project
@Date 4/18/19
*/


package Final;
import javax.swing.JFrame;
import java.awt.*;
import java.util.Scanner;
import javax.swing.JPanel;
public class Game {


 //creating an instance variable of a frame (graphic)
    
    private JFrame frame;  
    private int playerNum;
    private Scanner reader;
    private int currentPlayer;
    private Player[] players;
    private int[][] Board1= { {100,99,98,97,96,95,94,93,92,91},
        {81,82,83,84,85,86,87,88,89,90},
        {80,79,78,77,76,75,74,73,72,71},
        {61,62,63,64,65,66,67,68,69,70},
        {60,59,58,57,56,55,54,53,52,51},
        {41,42,43,44,45,46,47,48,49,50},
        {40,39,38,37,36,35,34,33,32,31},
        {21,22,23,24,25,26,27,28,29,30},
        {20,19,18,17,16,15,14,13,12,11},
        {1,2,3,4,5,6,7,8,9,10}};
    
                              
    
    
     //Constructor
    
    public Game(){ 
        
    //Making the Window played in
    
        frame=new JFrame("Snakes and Ladders");
        
        //min, max, and close buttons/opotions
        //teh closing 
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       reader = new Scanner(System.in);
       
        // setting default starting spot to player0
        
        currentPlayer=0;
    }
    
    public Player[] getPlayers(){
    return players;
            }

//methods
    
   public void play(){
       
       //prompting user to enter the amount of players playing the game
       
       System.out.println("Welcome to snakes and ladders, Created by Chris and Eddy, climb if you want. ");
       System.out.println("Enter amount of players playing the game today 4 is the maximum. ");
       playerNum=reader.nextInt();
       players = new Player[playerNum];
       
       //creating the desired number of players
       
       for(int i =0; i< playerNum; i++){
           
           //giving each of the 4 possible players a different color circle(gamepiece)
           
           switch(i%5){
               case 0:
                   players[i] = new Player(Color.orange, "" + (i+1) + " Orange ");
                   break;
               case 1:
                   players[i] = new Player(Color.red, "" + (i+1) + " Red");
                   break;
               case 2:
                   players[i] = new Player(Color.blue, "" +(i+1) + " Blue ");
                   break;
               case 3:
                   players[i] = new Player(Color.yellow, "" + (i+1) + " Purple");
                       break;
           }//switch end
       } //loop end
       
    //play method end
//gameplay loop

   boolean win=false;
   while (!win) {
       
    //while no one is at point 100 the game will contnune to ask for a dice roll.
    
       System.out.print("Player " + players[currentPlayer].getName()+ "'s turn. Type (R) to roll the Die " );
       
    // user types something in  
    
    reader.next();
    
    win = players[currentPlayer].roll();


   //graphics has the board in it
   
   //For loop to print board and player positions
   
   for(int i =0; i<Board1.length; i++){
       for (int j = 0; j < Board1[i].length; j++) {
           String square= "";
           Boolean playerPos= false;
           
           for (int k = 0; k <players.length ; k++) {
               if (players[k].getPosition().getPosition()==Board1[i][j])
               {
                   playerPos= true;
                   
                   square= square+players[k].getName().charAt(2);
                   
               }
               
           }
           if(playerPos){
               System.out.printf("%4s |",square);
               
           }
           else{
                   
               System.out.printf("%4d |", Board1[i][j]);
           }
           
       }
       System.out.println("");
       
   }
   
   JPanel board = new Board(this);
   frame.getContentPane().add(board);
   frame.pack();
   frame.setVisible(true);
   
        //this increments the player  
        
    if(!win){
    currentPlayer = (currentPlayer +1 ) % playerNum;
      }//ending of win loop
    
    //ending of game loop

}
   
   System.out.println("Player " + players[currentPlayer].getName() + " YOU HAVE WON THE GAME!!!! ");

   }


//main method
   
    public static void main(String[] args){
        Game game = new Game();
        game.play();
    } //end of main methid
} //end of class
    

