package Final;
public class Position {
    int p;
    //p is position
    
    //consructor
    public Position() {
        p=0;
    }
    
    //getters and setters
      public int getPosition(){
          return p;
      }   
      public void setPosition(){
          this.p=p;
      }
      // gets the x position on the board
      public int getX(){
          //looking for only even rows
          if (((p-1)/10)%2 ==0){
              return (((p-1)%10)*27);
          }
          //for odd rows
          else{
              return 243 - ((p-1)%10)*27;
      }
      }
      // getting the y position on the board
      public int getY(){
          return 243 - (((p-1)/10)*27);
          
      }
      
      //adding to players current position
          public boolean add(int steps){
              p+=steps;
              checkClimb();//method used if climbing a ladder
              checkBite();//method used if sliding down a snake from a bite
              if(p==100){
                  p=100;
                  return true;
              }
              if(p>100){
              p-=10;
            //if its not true
          }
        return false;
          }
          
          private void checkClimb(){
              switch(p) {
                  case 4:
                      p=14;
                      break;
                  case 9:
                      p=31;
                      break;
                  case 20:
                      p=38;
                      break;
                  case 28:
                      p=84;
                      break;
                  case 40:
                      p=59;
                      break;
                  case 51:
                      p=67;
                      break;
                  case 63:
                      p=81;
                      break;
                  case 71:
                      p=91;
                      break;
                  default:
                      return; //no ladder/climbing         
              }
              System.out.println("You climbed up a ladder!! ");
          }
          
          
         private void checkBite(){
             switch(p){
                 case 17:
                     p=7;
                     break;
                 case 54:
                     p=34;
                     break;
                 case 62:
                     p=19;
                     break;
                 case 64:
                     p=60;
                     break;
                 case 87:
                     p=24;
                     break;
                 case 93:
                     p=73;
                     break;
                 case 95:
                     p=75;
                     break;
                 case 99:
                     p=78;
                     break;
                 default:
                     return;                  
             }
             System.out.println("YOU GOT BIT BY A SNAKE ");
         }
}

             

