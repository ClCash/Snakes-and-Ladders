package Final;

import javax.swing.JPanel;
import java.awt.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.*;

// public class board is a j panel
public class Board extends JPanel{
    
    private Game game;
    
    
    //contructors
    //passing an instance of a game
    public Board(Game game){
        //setting the size of the board being used
        setPreferredSize(new Dimension(268,268));
        this.game=game;
    }
    
    

    // getters and setters
    //the drawing on the boarad will be done by this method from jPanel
    //passing instance of g for graphics
    public void  paintComponent(Graphics g){
        //so that tiles dont get printed over by background color
        super.paintComponent(g);
        //assign bufferedImage a variable " background" it null because its and object(image) nothing to assign to  it
        BufferedImage background= null;
        //doing a try catch to get the image file, by the possibility it is not there
      
        
        // going ot try to find our image file which is snl.gif and if it cant it will throw and IOexception 
        //so for the try we are trying to set background to the gif file
        try{
            background = ImageIO.read(new File("ladders.gif"));
        }catch(IOException e){
        //if it cant find the file then the catch statement will just draw a blank background
        //catch(IOException e){
        }
        
     g.drawImage(background, 0, 0, null);
     
    





    










    //drawing circles for players 
     // for player player in game.getPlayers getter method
    for (Player player: game.getPlayers()){
    //we are getting g from the paintComponent method it is are instance of ghraphics
    g.setColor(player.getColor());
    //draws the circles, the player pieces at their positions for each player
    g.fillOval(player.getPosition().getX(), player.getPosition().getY(),26,26);
    
    }//loop end 
 
  }//paint method end
}// class end
