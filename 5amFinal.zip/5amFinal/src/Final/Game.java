package Final;
import javax.swing.JFrame;
import java.awt.*;
import java.util.Scanner;
import javax.swing.JPanel;
public class Game {


 //creating an instance variable of a frame (graphic)
    private JFrame frame;  
    private int playerNum;
    private Scanner reader;
    private int currentPlayer;
    private Player[] players;


    //Constructor
    public Game(){ 
    //Making the Window played in 
        frame=new JFrame("Snakes and Ladders");
        //min, max, and close buttons/opotions
        //teh closing 
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       reader = new Scanner(System.in);
        // setting default starting spot to player0
        currentPlayer=0;
    }
    

//
    public Player[] getPlayers(){
    return players;
            }

//methods
   public void play(){
       //prompting user to enter the amount of players playing the game
       System.out.println("Welcome to snakes and ladders climb if you want. ");
       System.out.println("Enter amount of players playing the game today 4 is the maximum. ");
       playerNum=reader.nextInt();
       players = new Player[playerNum];
       //creating the desired number of players
       for(int i =0; i< playerNum; i++){
           //giving each of the 4 possible players a different color circle(gamepiece)
           switch(i%5){
               case 0:
                   players[i] = new Player(Color.orange, "" + (i+1) + " Orange ");
                   break;
               case 1:
                   players[i] = new Player(Color.red, "" + (i+1) + "Red");
                   break;
               case 2:
                   players[i] = new Player(Color.blue, "" +(i+1) + " Blue ");
                   break;
               case 3:
                   players[i] = new Player(Color.yellow, "" + (i+1) + "Purple");
                       break;
           }//switch end
       } //loop end
       
    //play method end
//gameplay loop
   boolean win=false;
   while (!win) {
    //while no one is at point 100 the game will contnune to ask for a dice roll.1
    
       System.out.print("Player " + players[currentPlayer].getName()+ "'s turn. Type (R) to roll the Die " );
    // user types something in  
    reader.next();
    
    win = players[currentPlayer].roll();


   //graphics has the board in it
   JPanel board = new Board(this);
   frame.getContentPane().add(board);
   frame.pack();
   frame.setVisible(true);
   
        //this increments the player    
    if(!win){
    currentPlayer = (currentPlayer +1 ) % playerNum;
      }//ending of win loop
    
    //ending of game loop

}
   
   System.out.println("Player " + players[currentPlayer].getName() + " YOU HAVE WON THE GAME!!!!2 ");

   }





//main method
    public static void main(String[] args){
        Game game = new Game();
        game.play();
    } //end of main methid
} //end of class
    

